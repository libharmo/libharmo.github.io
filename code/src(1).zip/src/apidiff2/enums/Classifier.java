package apidiff2.enums;

public enum Classifier {
	
	API, NON_API, INTERNAL, TEST, EXAMPLE, EXPERIMENTAL;
}

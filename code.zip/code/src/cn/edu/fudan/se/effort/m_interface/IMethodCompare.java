package cn.edu.fudan.se.effort.m_interface;


import cn.edu.fudan.se.effort.bean.MethodBean;

/**
 * 方法比较接口
 */
public interface IMethodCompare {

    double methodCompare(MethodBean m1, MethodBean m2);

}

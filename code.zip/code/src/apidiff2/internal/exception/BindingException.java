package apidiff2.internal.exception;

public class BindingException extends Exception {
	
}

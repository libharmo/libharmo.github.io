package refdiff.core2.api;

public interface Refactoring {

	public RefactoringType getRefactoringType();

	public String getName();

	public String toString();

}
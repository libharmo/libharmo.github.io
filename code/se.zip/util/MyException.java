package cn.edu.fudan.se.util;
public class MyException extends Exception {
  public MyException() {

  }
  public MyException(String s){
       super(s);
  }

}

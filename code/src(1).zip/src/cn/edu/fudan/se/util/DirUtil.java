package cn.edu.fudan.se.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class DirUtil {

    public static List<File> getAllFilesOfADirectory(String path){
        List<File> result = new ArrayList<>();
        browse(new File(path),result);
        return result;
    }


    public static List<File> getAllJavaFilesOfADirectory(String path){
        List<File> result = new ArrayList<>();
        browse(new File(path),result);
        List<File> collect = result.stream()
                .filter(a -> a.getAbsolutePath().endsWith(".java"))
                .collect(Collectors.toList());

        return collect;
    }


    private static void browse(File dir, List<File> mList){
        File[] files = dir.listFiles();
        for(File f:files){
            if(f.isDirectory()){
                browse(f,mList);
            }else{
                mList.add(f);
            }
        }
    }

    /**
     * 去除 .. .符号
     * @return
     */
    public static String trimPath(String path){
        path = path.replace("\\","/");
        String[] data = path.split("/");
        Set<Integer> a = new HashSet<>();
        for(int i =0;i<data.length;i++){
            String temp = data[i];
            if(i!=0 && "..".equals(temp)){
                a.add(i-1);
                a.add(i);
            }
            if(i!=0 && ".".equals(temp)){
                a.add(i);
            }
        }
        StringBuilder sb = new StringBuilder();
        for(int i =0;i<data.length;i++){
            if(a.contains(i)){
                continue;
            }
            sb.append(data[i]);
            sb.append("/");
        }
        String res = sb.toString();
        if(path.endsWith("/")){
            return res;
        }
        return res.substring(0,res.length()-1);
    }


}

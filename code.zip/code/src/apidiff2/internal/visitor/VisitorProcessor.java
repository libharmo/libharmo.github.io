package apidiff2.internal.visitor;

public class VisitorProcessor {

}

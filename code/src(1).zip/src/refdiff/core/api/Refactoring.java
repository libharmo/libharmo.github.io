package refdiff.core.api;

public interface Refactoring {

	public RefactoringType getRefactoringType();

	public String getName();

	public String toString();

}
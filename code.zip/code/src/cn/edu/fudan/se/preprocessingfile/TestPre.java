package cn.edu.fudan.se.preprocessingfile;

import cn.edu.fudan.se.preprocessingfile.data.PreprocessedData;

/**
 * Created by huangkaifeng on 2018/11/10.
 */
public class TestPre {

    public static void main(String args[]){
//        FilePairPreDiff preDiff = new FilePairPreDiff();
//        preDiff.initFileContent("a".getBytes(),"b".getBytes());
//        int result = preDiff.compareTwoFile();
//        JDTParserFactory.
        PreprocessedData d;
    }
}

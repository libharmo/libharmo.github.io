package cn.edu.fudan.se.effort.m_interface;

import cn.edu.fudan.se.effort.bean.VariableBean;

/**
 * 变量比较接口
 */
public interface IVariableCompare {
    double variableCompare(VariableBean v1, VariableBean v2);
}
